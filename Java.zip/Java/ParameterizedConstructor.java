// Parameterized constructor example
public class ParameterizedConstructor {
    int x;
    ParameterizedConstructor(int val) {
        x = val;
    }
    public static void main(String[] args) {
        ParameterizedConstructor obj = new ParameterizedConstructor(25);
        System.out.println("Value of x: " + obj.x);
    }
}

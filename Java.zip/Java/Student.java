// Program 1: Simple class and object
public class Student {
    String name = "John";
    int rollNo = 101;
    public static void main(String[] args) {
        Student s1 = new Student();
        System.out.println("Name: " + s1.name);
        System.out.println("Roll No: " + s1.rollNo);
    }
}

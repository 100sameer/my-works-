public class IncrementDecrementOperators {
    public static void main(String[] args) {
        int a = 5;
        System.out.println("a++: " + (a++));
        System.out.println("After a++: " + a);
        System.out.println("++a: " + (++a));
        System.out.println("a--: " + (a--));
        System.out.println("After a--: " + a);
        System.out.println("--a: " + (--a));
    }
}

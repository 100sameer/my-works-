public class DataTypesExample2 {
    public static void main(String[] args) {
        byte b = 100;
        short s = 10000;
        long l = 10000000000L;
        float f = 12.34f;
        String name = "Alice";
        System.out.println("Byte: " + b);
        System.out.println("Short: " + s);
        System.out.println("Long: " + l);
        System.out.println("Float: " + f);
        System.out.println("Name: " + name);
    }
}

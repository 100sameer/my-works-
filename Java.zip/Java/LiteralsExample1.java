// Integer, floating, character, string, and boolean literals
public class LiteralsExample1 {
    public static void main(String[] args) {
        int a = 100; // integer literal
        double b = 3.14; // floating-point literal
        char c = 'A'; // character literal
        String s = "Hello"; // string literal
        boolean flag = true; // boolean literal
        System.out.println("Integer: " + a);
        System.out.println("Double: " + b);
        System.out.println("Char: " + c);
        System.out.println("String: " + s);
        System.out.println("Boolean: " + flag);
    }
}

public class DataTypesExample1 {
    public static void main(String[] args) {
        int age = 20;
        double salary = 35000.50;
        char grade = 'A';
        boolean isEmployed = true;
        System.out.println("Age: " + age);
        System.out.println("Salary: " + salary);
        System.out.println("Grade: " + grade);
        System.out.println("Employed: " + isEmployed);
    }
}

// Copy constructor example (using another object)
public class CopyConstructor {
    int x;
    CopyConstructor(int val) {
        x = val;
    }
    CopyConstructor(CopyConstructor obj) {
        x = obj.x;
    }
    public static void main(String[] args) {
        CopyConstructor obj1 = new CopyConstructor(50);
        CopyConstructor obj2 = new CopyConstructor(obj1);
        System.out.println("Value of obj1.x: " + obj1.x);
        System.out.println("Value of obj2.x: " + obj2.x);
    }
}

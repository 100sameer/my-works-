// Using binary, octal, and hexadecimal integer literals
public class LiteralsExample2 {
    public static void main(String[] args) {
        int binary = 0b1010; // binary literal (10 in decimal)
        int octal = 012; // octal literal (10 in decimal)
        int hex = 0xA; // hexadecimal literal (10 in decimal)
        System.out.println("Binary literal: " + binary);
        System.out.println("Octal literal: " + octal);
        System.out.println("Hexadecimal literal: " + hex);
    }
}

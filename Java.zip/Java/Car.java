// Program 2: Class with method and multiple objects
public class Car {
    String model;
    int year;
    void setDetails(String m, int y) {
        model = m;
        year = y;
    }
    void display() {
        System.out.println("Model: " + model + ", Year: " + year);
    }
    public static void main(String[] args) {
        Car car1 = new Car();
        car1.setDetails("Toyota", 2020);
        car1.display();
        Car car2 = new Car();
        car2.setDetails("Honda", 2022);
        car2.display();
    }
}
